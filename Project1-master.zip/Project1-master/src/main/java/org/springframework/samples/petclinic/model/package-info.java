/**
 * The classes in this package represent utilities used by the domain.
 */
package org.springframework.samples.petclinic.model;

